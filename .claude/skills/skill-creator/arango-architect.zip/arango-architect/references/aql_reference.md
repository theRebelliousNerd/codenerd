# AQL (ArangoDB Query Language) Reference

Comprehensive AQL syntax guide for SymbioGen development with focus on graph operations and bitemporal queries.

## Table of Contents

1. [Basic Syntax](#basic-syntax)
2. [Common Operations](#common-operations)
3. [Graph Traversals](#graph-traversals)
4. [Aggregations](#aggregations)
5. [Subqueries](#subqueries)
6. [Functions](#functions)
7. [Bitemporal Patterns](#bitemporal-patterns)
8. [Performance Optimization](#performance-optimization)

---

## Basic Syntax

### FOR Loop (Iteration)

```aql
// Iterate over collection
FOR doc IN contacts
RETURN doc

// With variable binding
FOR contact IN contacts
RETURN contact.name

// Multiple iterators
FOR contact IN contacts
FOR org IN organizations
RETURN {contact, org}
```

### FILTER (Selection)

```aql
// Simple filter
FOR doc IN contacts
FILTER doc.age > 25
RETURN doc

// Multiple conditions (AND)
FOR doc IN contacts
FILTER doc.age > 25
FILTER doc.department == "Engineering"
RETURN doc

// OR conditions
FOR doc IN contacts
FILTER doc.age > 25 OR doc.department == "Engineering"
RETURN doc

// Complex conditions
FOR doc IN contacts
FILTER (doc.age > 25 AND doc.department == "Engineering")
    OR doc.title == "Director"
RETURN doc
```

### RETURN (Projection)

```aql
// Return full document
FOR doc IN contacts
RETURN doc

// Return specific fields
FOR doc IN contacts
RETURN {
    name: doc.name,
    email: doc.email
}

// Return computed values
FOR doc IN contacts
RETURN {
    fullName: CONCAT(doc.firstName, " ", doc.lastName),
    ageBracket: doc.age < 30 ? "young" : "senior"
}

// Return with aliases
FOR doc IN contacts
RETURN {
    id: doc._key,
    displayName: doc.name,
    contact: doc.email
}
```

### SORT (Ordering)

```aql
// Ascending sort
FOR doc IN contacts
SORT doc.name ASC
RETURN doc

// Descending sort
FOR doc IN contacts
SORT doc.created_at DESC
RETURN doc

// Multiple sort fields
FOR doc IN contacts
SORT doc.department ASC, doc.salary DESC
RETURN doc

// Sort with null handling
FOR doc IN contacts
SORT doc.age ASC NULLS FIRST
RETURN doc
```

### LIMIT (Pagination)

```aql
// Limit results
FOR doc IN contacts
LIMIT 10
RETURN doc

// Offset and limit (pagination)
FOR doc IN contacts
LIMIT 20, 10  // Skip 20, take 10
RETURN doc

// Common pagination pattern
FOR doc IN contacts
SORT doc.created_at DESC
LIMIT @offset, @limit
RETURN doc
```

---

## Common Operations

### LET (Variable Assignment)

```aql
// Assign computed value
FOR doc IN contacts
LET fullName = CONCAT(doc.firstName, " ", doc.lastName)
RETURN {
    id: doc._id,
    name: fullName
}

// Assign subquery result
FOR contact IN contacts
LET orgs = (
    FOR org IN organizations
    FILTER org.contact_id == contact._id
    RETURN org
)
RETURN {
    contact: contact,
    organizations: orgs
}
```

### COLLECT (Grouping)

```aql
// Simple grouping
FOR doc IN contacts
COLLECT department = doc.department
RETURN {
    department: department
}

// Grouping with aggregation
FOR doc IN contacts
COLLECT department = doc.department
AGGREGATE count = LENGTH(1)
RETURN {
    department: department,
    employeeCount: count
}

// Multiple grouping keys
FOR doc IN contacts
COLLECT
    department = doc.department,
    location = doc.location
AGGREGATE count = LENGTH(1), avgAge = AVERAGE(doc.age)
RETURN {
    department,
    location,
    count,
    avgAge
}

// Group with INTO (collect all documents)
FOR doc IN contacts
COLLECT department = doc.department INTO groups
RETURN {
    department: department,
    members: groups[*].doc
}
```

### INSERT, UPDATE, REPLACE, REMOVE

```aql
// INSERT
INSERT {
    _key: "new_contact",
    name: "John Doe",
    email: "john@example.com",
    created_at: DATE_ISO8601(DATE_NOW())
} INTO contacts

// INSERT with RETURN
INSERT {
    name: "Jane Smith",
    email: "jane@example.com"
} INTO contacts
RETURN NEW  // Returns inserted document

// UPDATE (merge)
UPDATE "contact_key" WITH {
    email: "newemail@example.com",
    updated_at: DATE_ISO8601(DATE_NOW())
} IN contacts

// UPDATE with FILTER
FOR doc IN contacts
FILTER doc.department == "Engineering"
UPDATE doc WITH {
    salary: doc.salary * 1.1  // 10% raise
} IN contacts

// REPLACE (full replacement)
REPLACE "contact_key" WITH {
    name: "John Doe",
    email: "john@newdomain.com",
    department: "Sales"
} IN contacts

// REMOVE
REMOVE "contact_key" IN contacts

// REMOVE with FILTER
FOR doc IN contacts
FILTER doc.inactive == true
REMOVE doc IN contacts
```

### UPSERT (Insert or Update)

```aql
// Upsert pattern
UPSERT { _key: "contact_123" }
INSERT {
    _key: "contact_123",
    name: "John Doe",
    email: "john@example.com",
    created_at: DATE_ISO8601(DATE_NOW())
}
UPDATE {
    email: "john@example.com",
    updated_at: DATE_ISO8601(DATE_NOW())
}
IN contacts
```

---

## Graph Traversals

### Basic Traversal

```aql
// Traverse outbound edges
FOR vertex IN 1..3 OUTBOUND @startVertex
GRAPH @graphName
RETURN vertex

// Traverse inbound edges
FOR vertex IN 1..2 INBOUND @startVertex
GRAPH @graphName
RETURN vertex

// Traverse any direction
FOR vertex IN 1..3 ANY @startVertex
GRAPH @graphName
RETURN vertex
```

### Traversal with Edge and Path

```aql
// Get vertex, edge, and path information
FOR vertex, edge, path IN 1..3 OUTBOUND @startVertex
GRAPH @graphName
RETURN {
    vertex: vertex,
    edge: edge,
    path_length: LENGTH(path.edges),
    full_path: path.vertices
}
```

### Traversal Options

```aql
// Breadth-first search
FOR vertex IN 1..3 OUTBOUND @startVertex
GRAPH @graphName
OPTIONS {
    bfs: true,
    uniqueVertices: 'global'
}
RETURN vertex

// Depth-first search with pruning
FOR vertex, edge, path IN 1..5 OUTBOUND @startVertex
GRAPH @graphName
OPTIONS {
    bfs: false,
    uniqueVertices: 'path'
}
PRUNE vertex.stop_here == true
RETURN vertex
```

### Named Graph Traversal

```aql
// Using defined graph
FOR v, e, p IN 1..3 OUTBOUND "contacts/john_doe"
GRAPH "business_network"
RETURN {
    name: v.name,
    relationship: e.type,
    hops: LENGTH(p.edges)
}
```

### Edge Collection Traversal

```aql
// Traverse specific edge collections (not using named graph)
FOR v, e IN 1..2 OUTBOUND "contacts/john_doe"
works_with, knows
RETURN {vertex: v, edge: e}
```

### Shortest Path

```aql
// Find shortest path between two vertices
FOR path IN OUTBOUND SHORTEST_PATH
@startVertex TO @endVertex
GRAPH @graphName
RETURN path

// With edges and vertices
FOR path IN OUTBOUND SHORTEST_PATH
"contacts/john_doe" TO "contacts/jane_smith"
GRAPH "business_network"
RETURN {
    vertices: path.vertices,
    edges: path.edges,
    distance: LENGTH(path.edges)
}
```

### k-Shortest Paths

```aql
// Find multiple shortest paths
FOR path IN OUTBOUND K_SHORTEST_PATHS
@startVertex TO @endVertex
GRAPH @graphName
OPTIONS {k: 5}
RETURN path
```

### Pattern Matching

```aql
// Find specific patterns in graph
FOR start IN contacts
FOR v, e, p IN 2..2 OUTBOUND start
works_with, knows
FILTER p.edges[0].type == "colleague"
FILTER p.edges[1].type == "friend"
RETURN {
    start: start.name,
    middle: p.vertices[1].name,
    end: v.name
}
```

---

## Aggregations

### COUNT

```aql
// Simple count
RETURN LENGTH(contacts)

// Count with filter
FOR doc IN contacts
FILTER doc.department == "Engineering"
COLLECT WITH COUNT INTO count
RETURN count
```

### SUM, AVERAGE, MIN, MAX

```aql
// Aggregate functions
FOR doc IN contacts
COLLECT AGGREGATE
    total_salary = SUM(doc.salary),
    avg_age = AVERAGE(doc.age),
    min_age = MIN(doc.age),
    max_age = MAX(doc.age),
    count = LENGTH(doc)
RETURN {
    total_salary,
    avg_age,
    min_age,
    max_age,
    count
}
```

### Group Aggregations

```aql
// Aggregate by group
FOR doc IN contacts
COLLECT department = doc.department
AGGREGATE
    count = LENGTH(1),
    avg_salary = AVERAGE(doc.salary),
    total_budget = SUM(doc.salary)
RETURN {
    department,
    employee_count: count,
    average_salary: avg_salary,
    total_budget: total_budget
}
```

### DISTINCT

```aql
// Get distinct values
FOR doc IN contacts
RETURN DISTINCT doc.department

// Distinct with collect
FOR doc IN contacts
COLLECT department = doc.department
RETURN department
```

---

## Subqueries

### Nested FOR Loops

```aql
// Join pattern
FOR contact IN contacts
FOR org IN organizations
FILTER contact.organization_id == org._key
RETURN {
    contact: contact.name,
    organization: org.name
}
```

### LET with Subquery

```aql
// Subquery in LET
FOR contact IN contacts
LET related_orgs = (
    FOR org IN organizations
    FILTER org.contact_id == contact._id
    RETURN org.name
)
RETURN {
    contact: contact.name,
    organizations: related_orgs
}
```

### Correlated Subquery

```aql
// Subquery dependent on outer query
FOR contact IN contacts
LET activity_count = LENGTH(
    FOR activity IN activities
    FILTER activity.contact_id == contact._id
    RETURN 1
)
FILTER activity_count > 10
RETURN {
    contact: contact.name,
    activities: activity_count
}
```

---

## Functions

### String Functions

```aql
// CONCAT - Concatenate strings
RETURN CONCAT("Hello", " ", "World")  // "Hello World"

// UPPER, LOWER - Case conversion
RETURN UPPER("hello")  // "HELLO"
RETURN LOWER("WORLD")  // "world"

// SUBSTRING - Extract substring
RETURN SUBSTRING("Hello World", 0, 5)  // "Hello"

// LENGTH - String length
RETURN LENGTH("Hello")  // 5

// TRIM - Remove whitespace
RETURN TRIM("  hello  ")  // "hello"

// CONTAINS - Check substring
RETURN CONTAINS("Hello World", "World")  // true

// LIKE - Pattern matching
FOR doc IN contacts
FILTER LIKE(doc.email, "%@gmail.com")
RETURN doc
```

### Array Functions

```aql
// LENGTH - Array length
RETURN LENGTH([1, 2, 3, 4])  // 4

// PUSH, APPEND - Add to array
RETURN PUSH([1, 2], 3)  // [1, 2, 3]
RETURN APPEND([1, 2], [3, 4])  // [1, 2, 3, 4]

// UNIQUE - Remove duplicates
RETURN UNIQUE([1, 2, 2, 3, 3, 3])  // [1, 2, 3]

// FLATTEN - Flatten nested arrays
RETURN FLATTEN([[1, 2], [3, 4]])  // [1, 2, 3, 4]

// SLICE - Extract portion
RETURN SLICE([1, 2, 3, 4, 5], 1, 3)  // [2, 3, 4]

// FIRST, LAST - Get first/last element
RETURN FIRST([1, 2, 3])  // 1
RETURN LAST([1, 2, 3])  // 3

// POSITION - Find element index
RETURN POSITION([1, 2, 3], 2)  // 1

// INTERSECTION, UNION, MINUS - Set operations
RETURN INTERSECTION([1, 2, 3], [2, 3, 4])  // [2, 3]
RETURN UNION([1, 2], [2, 3])  // [1, 2, 3]
RETURN MINUS([1, 2, 3], [2])  // [1, 3]
```

### Date/Time Functions

```aql
// DATE_NOW - Current timestamp (milliseconds)
RETURN DATE_NOW()

// DATE_ISO8601 - Convert to ISO 8601 string
RETURN DATE_ISO8601(DATE_NOW())  // "2025-10-30T12:00:00.000Z"

// DATE_TIMESTAMP - Convert ISO to milliseconds
RETURN DATE_TIMESTAMP("2025-01-01T00:00:00.000Z")

// DATE_ADD - Add duration
RETURN DATE_ADD(DATE_NOW(), 7, "days")
RETURN DATE_ADD("2025-01-01", 1, "year")

// DATE_SUBTRACT - Subtract duration
RETURN DATE_SUBTRACT(DATE_NOW(), 30, "days")

// DATE_DIFF - Difference between dates
RETURN DATE_DIFF("2025-01-01", "2025-12-31", "days")  // ~365

// DATE_COMPARE - Compare dates
RETURN DATE_COMPARE("2025-01-01", "2025-12-31")  // -1 (first is earlier)

// DATE_FORMAT - Format date string
RETURN DATE_FORMAT(DATE_NOW(), "%yyyy-%mm-%dd")
```

### Numeric Functions

```aql
// FLOOR, CEIL, ROUND - Rounding
RETURN FLOOR(3.7)  // 3
RETURN CEIL(3.2)  // 4
RETURN ROUND(3.5)  // 4

// ABS - Absolute value
RETURN ABS(-5)  // 5

// SQRT, POW - Square root, power
RETURN SQRT(16)  // 4
RETURN POW(2, 3)  // 8

// RAND - Random number
RETURN RAND()  // Random float 0-1
```

### Document Functions

```aql
// DOCUMENT - Get document by ID
FOR id IN ["contacts/john", "contacts/jane"]
LET doc = DOCUMENT(id)
RETURN doc

// KEEP, UNSET - Filter attributes
FOR doc IN contacts
RETURN KEEP(doc, "name", "email")  // Only these fields

FOR doc IN contacts
RETURN UNSET(doc, "_id", "_rev", "_key")  // Remove these fields

// MERGE - Merge objects
FOR doc IN contacts
RETURN MERGE(doc, {
    full_name: CONCAT(doc.first_name, " ", doc.last_name)
})

// HAS - Check attribute existence
FOR doc IN contacts
FILTER HAS(doc, "email")
RETURN doc
```

### Conditional Functions

```aql
// Ternary operator
FOR doc IN contacts
RETURN {
    name: doc.name,
    status: doc.age >= 18 ? "adult" : "minor"
}

// FIRST_DOCUMENT - Return first non-null
RETURN FIRST_DOCUMENT([null, null, {name: "John"}])  // {name: "John"}

// NOT_NULL - Return first non-null value
RETURN NOT_NULL(null, null, "default")  // "default"
```

---

## Bitemporal Patterns

### Current Valid State

```aql
// Get currently valid entities
FOR doc IN contacts
FILTER doc.valid_from <= DATE_NOW()
FILTER doc.valid_to == null OR doc.valid_to > DATE_NOW()
RETURN doc
```

### Historical Query (As-Of Date)

```aql
// "What did we know on this date?"
LET query_date = DATE_TIMESTAMP("2025-03-15T00:00:00Z")

FOR doc IN contacts
FILTER doc.valid_from <= query_date
FILTER doc.valid_to == null OR doc.valid_to > query_date
FILTER doc.transaction_time <= query_date
RETURN doc
```

### Temporal Evolution

```aql
// Track how an entity changed over time
FOR doc IN contacts
FILTER doc._key == @entity_key
SORT doc.valid_from ASC
RETURN {
    valid_from: doc.valid_from,
    valid_to: doc.valid_to,
    transaction_time: doc.transaction_time,
    state: doc
}
```

### Retroactive Analysis

```aql
// "What opportunities did we miss?"
LET discovery_date = DATE_TIMESTAMP("2025-03-01")

FOR opp IN opportunities
FILTER opp.valid_from < discovery_date  // Opportunity existed
FILTER opp.transaction_time > discovery_date  // But we learned late
RETURN {
    opportunity: opp.title,
    existed_since: opp.valid_from,
    discovered_on: opp.transaction_time,
    delay_days: DATE_DIFF(opp.valid_from, opp.transaction_time, "days")
}
```

---

## Performance Optimization

### Early Filtering

```aql
// GOOD - Filter early
FOR doc IN large_collection
FILTER doc.indexed_field == @value  // Filter immediately
FILTER doc.other_condition
LET computed = EXPENSIVE_FUNCTION(doc)
RETURN {doc, computed}

// BAD - Late filtering
FOR doc IN large_collection
LET computed = EXPENSIVE_FUNCTION(doc)  // Computed for all docs
FILTER doc.indexed_field == @value  // Filter too late
RETURN {doc, computed}
```

### Index Usage

```aql
// Use indexed fields in FILTER
FOR doc IN contacts
FILTER doc.email == @email  // If email has index
RETURN doc

// Compound index usage
FOR doc IN contacts
FILTER doc.organization_id == @org_id  // First index field
FILTER doc.created_at >= @start_date  // Second index field
SORT doc.created_at DESC  // Uses index for sorting too
RETURN doc
```

### Projection (Reduce Data Transfer)

```aql
// GOOD - Return only needed fields
FOR doc IN large_collection
RETURN {
    id: doc._key,
    name: doc.name,
    email: doc.email
}

// BAD - Return full documents
FOR doc IN large_collection
RETURN doc  // Transfers all fields
```

### LIMIT Usage

```aql
// Always use LIMIT for large result sets
FOR doc IN contacts
FILTER doc.department == "Engineering"
SORT doc.created_at DESC
LIMIT 100  // Prevent unbounded result sets
RETURN doc
```

### Avoid Cartesian Products

```aql
// BAD - Cartesian product
FOR contact IN contacts
FOR org IN organizations  // No filter!
RETURN {contact, org}  // N * M results

// GOOD - Filtered join
FOR contact IN contacts
FOR org IN organizations
FILTER contact.organization_id == org._id
RETURN {contact, org}
```

### Subquery Optimization

```aql
// GOOD - Filter in subquery
FOR contact IN contacts
LET activities = (
    FOR activity IN activities
    FILTER activity.contact_id == contact._id  // Filter early
    FILTER activity.type == "important"
    LIMIT 10
    RETURN activity
)
RETURN {contact, activities}

// BAD - No filter in subquery
FOR contact IN contacts
LET all_activities = (
    FOR activity IN activities
    RETURN activity  // Gets ALL activities
)
RETURN {contact, all_activities}  // Then filters later
```

---

## Query Patterns

### Pagination Pattern

```aql
// Standard pagination
FOR doc IN contacts
SORT doc.created_at DESC
LIMIT @offset, @limit
RETURN doc

// With total count
LET total = LENGTH(
    FOR doc IN contacts
    RETURN 1
)
LET results = (
    FOR doc IN contacts
    SORT doc.created_at DESC
    LIMIT @offset, @limit
    RETURN doc
)
RETURN {
    total: total,
    results: results
}
```

### Search Pattern

```aql
// Full-text search (requires fulltext index)
FOR doc IN FULLTEXT(contacts, "description", @searchTerm)
RETURN doc

// Multi-field search
FOR doc IN contacts
FILTER CONTAINS(LOWER(doc.name), LOWER(@term))
    OR CONTAINS(LOWER(doc.email), LOWER(@term))
    OR CONTAINS(LOWER(doc.description), LOWER(@term))
RETURN doc
```

### Deduplication Pattern

```aql
// Remove duplicates based on field
FOR doc IN contacts
COLLECT email = doc.email
INTO groups
RETURN FIRST(groups[*].doc)
```

---

See also:
- [API Patterns](./api_patterns.md) for python-arango-async usage
- [Schema Design](./schema_design.md) for collection architecture
- [SymbioGen Patterns](./symbiogen_patterns.md) for real-world examples
