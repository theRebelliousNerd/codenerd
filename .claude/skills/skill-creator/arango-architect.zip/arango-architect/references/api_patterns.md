# python-arango-async API Patterns Reference

Comprehensive guide to python-arango-async patterns for SymbioGen development.

## Table of Contents

1. [Client Initialization](#client-initialization)
2. [Connection Patterns](#connection-patterns)
3. [Database Operations](#database-operations)
4. [Collection Management](#collection-management)
5. [Document Operations](#document-operations)
6. [AQL Query Execution](#aql-query-execution)
7. [Graph Operations](#graph-operations)
8. [Transaction Management](#transaction-management)
9. [Async Job Patterns](#async-job-patterns)
10. [Error Handling](#error-handling)

---

## Client Initialization

### Basic Client Setup

```python
from arangoasync import ArangoClient
from arangoasync.auth import Auth

# Async context manager (recommended)
async with ArangoClient(hosts="http://localhost:8529") as client:
    auth = Auth(username="root", password="passwd")
    db = await client.db("symbiogen_db", auth=auth)
    # Perform operations...
```

### Manual Client Management

```python
# When context manager not suitable
client = ArangoClient(hosts="http://localhost:8529")
auth = Auth(username="root", password="passwd")
db = await client.db("symbiogen_db", auth=auth)

# Perform operations...

# IMPORTANT: Close client manually
await client.close()
```

### Client Configuration Options

```python
client = ArangoClient(
    hosts="http://localhost:8529",
    timeout=60,  # Request timeout in seconds
    verify_ssl=True,  # SSL certificate verification
    serializer=CustomJsonSerializer(),  # Optional custom serializer
    deserializer=CustomJsonDeserializer()  # Optional custom deserializer
)
```

---

## Connection Patterns

### SymbioGen Connection Pool Pattern

SymbioGen uses a connection pool for efficiency and resource management.

```python
from ai_engine.db.connection_pool import get_connection_pool

# Get pooled connection
pool = await get_connection_pool()
db = await pool.acquire()

try:
    # Perform operations
    results = await db.execute_aql("FOR doc IN collection RETURN doc")
finally:
    # Always release back to pool
    await pool.release(db)
```

### Wrapper Pattern (SymbioGen's AsyncDatabaseWrapper)

```python
from ai_engine.db.async_connection import get_async_connection

# Get singleton wrapper instance
db = await get_async_connection()

# Wrapper provides convenience methods
results = await db.execute_aql(query, bind_vars)
await db.collection_insert("my_collection", document)
await db.collection_update("my_collection", updated_doc)

# No manual close needed (managed by wrapper)
```

### Context Manager Pattern

```python
from ai_engine.db.async_connection import get_async_db

async with get_async_db() as db:
    # Connection auto-acquired
    results = await db.execute_aql(query)
    # Connection auto-released on exit
```

---

## Database Operations

### Check Database Existence

```python
# Via client
if await client.has_database("symbiogen_db"):
    db = await client.db("symbiogen_db", auth=auth)
```

### Create Database

```python
# Connect to _system database first
sys_db = await client.db("_system", auth=auth)

# Create new database
await sys_db.create_database("new_db")
```

### List Databases

```python
sys_db = await client.db("_system", auth=auth)
databases = await sys_db.databases()
# Returns: ['_system', 'symbiogen_db', ...]
```

---

## Collection Management

### Check Collection Existence

```python
if await db.has_collection("contacts"):
    collection = db.collection("contacts")
```

### Create Collection

```python
# Standard document collection
collection = await db.create_collection("contacts")

# With options
collection = await db.create_collection(
    "contacts",
    edge=False,  # False for document collection, True for edge collection
    sync=True,  # Wait for sync to disk
    key_generator="traditional"  # Key generation strategy
)
```

### Create Edge Collection

```python
# Edge collections store graph relationships
edges = await db.create_collection("works_with", edge=True)
```

### List Collections

```python
collections = await db.collections()
for coll in collections:
    print(f"Name: {coll['name']}, Type: {coll['type']}")
```

### Delete Collection

```python
await db.delete_collection("old_collection")
```

---

## Document Operations

### Insert Single Document

```python
collection = db.collection("contacts")

# Insert returns metadata
metadata = await collection.insert({
    "_key": "john_doe",  # Optional explicit key
    "name": "John Doe",
    "email": "john@example.com",
    "age": 30
})

# metadata contains: {'_id', '_key', '_rev'}
print(f"Inserted: {metadata['_id']}")
```

### Insert Multiple Documents (Bulk)

```python
documents = [
    {"_key": "jane", "name": "Jane Smith", "age": 28},
    {"_key": "bob", "name": "Bob Johnson", "age": 35}
]

# Bulk insert
results = await collection.insert_many(documents)

# results is list of metadata dicts
for result in results:
    if result.get("error"):
        print(f"Error: {result['errorMessage']}")
    else:
        print(f"Inserted: {result['_id']}")
```

### Get Document by Key

```python
# By key
document = await collection.get("john_doe")

# By _id
document = await collection.get("contacts/john_doe")
```

### Get Multiple Documents

```python
keys = ["john_doe", "jane", "bob"]
documents = await collection.get_many(keys)

# Returns list of documents (None for missing keys)
for doc in documents:
    if doc:
        print(f"Found: {doc['name']}")
```

### Check Document Existence

```python
if await collection.has("john_doe"):
    print("Document exists")
```

### Update Document (Merge)

```python
# Partial update (merge with existing)
result = await collection.update({
    "_key": "john_doe",
    "age": 31,  # Update age
    "department": "Engineering"  # Add new field
}, keep_none=False, merge=True)

# keep_none=False removes null values
# merge=True merges with existing (default)
```

### Replace Document (Full Replacement)

```python
# Complete replacement
result = await collection.replace({
    "_key": "john_doe",
    "name": "John Doe",
    "email": "john.new@example.com",
    "age": 31
    # All other fields removed
})
```

### Delete Document

```python
# By key
await collection.delete("john_doe")

# By document
await collection.delete({"_key": "john_doe"})
```

### Count Documents

```python
count = await collection.count()
print(f"Total documents: {count}")
```

---

## AQL Query Execution

### Basic Query Execution

```python
query = """
FOR doc IN contacts
FILTER doc.age > @min_age
SORT doc.name ASC
RETURN doc
"""

bind_vars = {"min_age": 25}

cursor = await db.aql.execute(query, bind_vars=bind_vars)

# Iterate results
results = []
async for doc in cursor:
    results.append(doc)
```

### Query with Options

```python
cursor = await db.aql.execute(
    query,
    bind_vars=bind_vars,
    count=True,  # Include total count in cursor
    batch_size=100,  # Number of docs per batch
    ttl=3600,  # Cursor TTL in seconds
    cache=True,  # Enable query result cache
    max_plans=10  # Optimizer plans to try
)

# Access count if requested
if cursor.count:
    print(f"Total results: {cursor.count()}")
```

### Query Validation

```python
# Validate without executing
is_valid = await db.aql.validate(query)

if not is_valid:
    print("Invalid query")
```

### Query Explanation (Execution Plan)

```python
# Get execution plan
plan = await db.aql.explain(query, bind_vars=bind_vars)

# Inspect plan details
print(f"Estimated cost: {plan['estimatedCost']}")
print(f"Estimated results: {plan['estimatedNrResults']}")
for node in plan['nodes']:
    print(f"Node type: {node['type']}")
```

### Cursor Management

```python
# Using async context manager
async with await db.aql.execute(query) as cursor:
    async for doc in cursor:
        process(doc)
    # Cursor automatically closed

# Manual cursor management
cursor = await db.aql.execute(query)
try:
    results = [doc async for doc in cursor]
finally:
    await cursor.close()
```

---

## Graph Operations

### Create Graph

```python
if not await db.has_graph("business_network"):
    graph = await db.create_graph("business_network")
else:
    graph = db.graph("business_network")
```

### Create Vertex Collection

```python
# Vertex collections are just document collections in graph context
if not await graph.has_vertex_collection("contacts"):
    vertices = await graph.create_vertex_collection("contacts")
```

### Create Edge Definition

```python
# Define relationship
await graph.create_edge_definition(
    edge_collection="works_with",
    from_vertex_collections=["contacts"],
    to_vertex_collections=["organizations"]
)
```

### Insert Vertex

```python
contacts = graph.vertex_collection("contacts")

await contacts.insert({
    "_key": "john_doe",
    "name": "John Doe",
    "title": "Engineer"
})
```

### Insert Edge

```python
edges = graph.edge_collection("works_with")

await edges.insert({
    "_from": "contacts/john_doe",
    "_to": "organizations/acme_corp",
    "role": "Senior Engineer",
    "start_date": "2020-01-01"
})
```

### Graph Traversal via AQL

```python
# Find all paths from a starting vertex
query = """
FOR vertex, edge, path IN 1..3 OUTBOUND @start_vertex
GRAPH @graph_name
OPTIONS {
    bfs: true,  # Breadth-first search
    uniqueVertices: 'global'  # No duplicate vertices
}
RETURN {
    vertex: vertex,
    edge: edge,
    path_length: LENGTH(path.vertices),
    full_path: path
}
"""

results = await db.execute_aql(query, {
    "start_vertex": "contacts/john_doe",
    "graph_name": "business_network"
})
```

### Vertex Operations (Graph-Level)

```python
# Get vertex
vertex = await graph.vertex("contacts/john_doe")

# Update vertex
await graph.update_vertex({
    "_id": "contacts/john_doe",
    "title": "Lead Engineer"
})

# Replace vertex
await graph.replace_vertex({
    "_id": "contacts/john_doe",
    "name": "John Doe",
    "title": "Principal Engineer"
})

# Delete vertex
await graph.delete_vertex("contacts/john_doe")
```

---

## Transaction Management

### Begin Transaction

```python
# Start transaction with read/write collections
txn_db = await db.begin_transaction(
    read=["contacts", "organizations"],
    write=["contacts"]
)

# Get transaction ID
txn_id = txn_db.transaction_id
```

### Transaction Operations

```python
# All operations use transaction-specific wrappers
txn_collection = txn_db.collection("contacts")

# Operations within transaction
await txn_collection.insert({"_key": "jane", "name": "Jane"})
await txn_collection.update({"_key": "john", "age": 32})

# Query within transaction
txn_aql = txn_db.aql
results = await txn_aql.execute("FOR doc IN contacts RETURN doc")
```

### Commit Transaction

```python
# Commit all operations
await txn_db.commit_transaction()

# Verify changes
assert await db.collection("contacts").has("jane")
```

### Abort Transaction

```python
# Rollback all operations
await txn_db.abort_transaction()

# Changes not persisted
assert not await db.collection("contacts").has("jane")
```

### Check Transaction Status

```python
status = await txn_db.transaction_status()
# Returns: 'running', 'committed', or 'aborted'
```

---

## Async Job Patterns

### Begin Async Execution

```python
# Enter async mode
async_db = db.begin_async_execution(return_result=True)

# All operations return AsyncJob objects
job1 = await async_db.collection("contacts").insert({"_key": "async_doc"})
job2 = await async_db.aql.execute("FOR doc IN contacts RETURN doc")
```

### Monitor Job Status

```python
# Check status
status = await job1.status()
# Returns: 'pending' or 'done'

# Wait for completion
import time
while await job1.status() != "done":
    await asyncio.sleep(0.1)
```

### Retrieve Job Results

```python
# Get result once done
result = await job1.result()

# For queries, result is cursor
cursor = await job2.result()
results = [doc async for doc in cursor]
```

### Handle Job Errors

```python
try:
    result = await job.result()
except AQLQueryExecuteError as e:
    logger.error(f"Query failed: {e.http_code} - {e.message}")
```

### Cancel Job

```python
# Cancel pending job
try:
    await job.cancel()
except AsyncJobCancelError:
    # Job already done or not cancellable
    pass
```

### Clear Job Result

```python
# Free server resources
try:
    await job.clear()
except AsyncJobClearError:
    # Result already cleared
    pass
```

### List Async Jobs

```python
# List pending jobs
pending = await db.async_jobs(status='pending', count=100)

# List completed jobs
done = await db.async_jobs(status='done', count=100)
```

---

## Error Handling

### Common Exceptions

```python
from arangoasync.exceptions import (
    AQLQueryExecuteError,
    DocumentInsertError,
    DocumentUpdateError,
    DocumentDeleteError,
    CollectionCreateError,
    TransactionAbortError
)
```

### Comprehensive Error Handling

```python
async def safe_operation():
    try:
        result = await db.aql.execute(query, bind_vars)
        return result

    except AQLQueryExecuteError as e:
        logger.error(
            f"AQL error: {e.message}",
            extra={
                "http_code": e.http_code,
                "error_num": e.error_code,
                "query": query
            }
        )
        raise

    except DocumentInsertError as e:
        logger.error(f"Insert failed: {e.message}")
        raise

    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise
```

### Retry Logic Pattern

```python
from tenacity import retry, stop_after_attempt, wait_exponential

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=10)
)
async def resilient_query():
    db = await get_async_connection()
    return await db.execute_aql(query, bind_vars)
```

---

## SymbioGen-Specific Patterns

### Using DatabaseService (Preferred)

```python
from ai_engine.db.database_service import DatabaseService

async def symbiogen_query():
    db = DatabaseService()
    await db.initialize()

    # Automatic caching
    results = await db.execute_aql(
        query,
        bind_vars,
        use_cache=True,
        cache_ttl=300
    )

    return results
```

### Agent Database Service Pattern

```python
from ai_engine.db.database_service import DatabaseService

class MyAgentDatabaseService(DatabaseService):
    def __init__(self):
        super().__init__()
        self.collections = {
            'primary': 'my_agent_data',
            'cache': 'my_agent_cache'
        }

    async def agent_specific_operation(self, params):
        query = """
        FOR doc IN @@collection
        FILTER doc.param == @value
        RETURN doc
        """

        return await self.execute_aql(query, {
            "@collection": self.collections['primary'],
            "value": params.get("value")
        })
```

---

## Best Practices

1. **Always use async/await**: python-arango-async is fully async
2. **Use context managers**: For automatic resource cleanup
3. **Use bind variables**: Prevent AQL injection, enable caching
4. **Batch operations**: Use insert_many for bulk inserts
5. **Connection pooling**: Reuse connections via pool
6. **Error handling**: Always handle exceptions explicitly
7. **Cursor cleanup**: Use async context managers for cursors
8. **Transaction scope**: Keep transactions small and focused
9. **Index usage**: Ensure filters use indexed fields
10. **Monitoring**: Log query execution times and errors

---

## Quick Reference: Common Operations

```python
# Initialize
db = await get_async_connection()

# Insert
await db.collection_insert("coll", {"key": "value"})

# Query
results = await db.execute_aql("FOR doc IN coll RETURN doc")

# Update
await db.collection_update("coll", {"_key": "id", "field": "new"})

# Delete
await db.collection_delete("coll", "key")

# Transaction
txn = await db.begin_transaction(write=["coll"])
await txn.collection("coll").insert(doc)
await txn.commit_transaction()

# Graph
graph = await db.create_graph("graph_name")
await graph.create_edge_definition("edges", ["from"], ["to"])
```

---

See also:
- [AQL Reference](./aql_reference.md) for AQL query syntax
- [Schema Design](./schema_design.md) for collection design patterns
- [SymbioGen Patterns](./symbiogen_patterns.md) for implementation examples
