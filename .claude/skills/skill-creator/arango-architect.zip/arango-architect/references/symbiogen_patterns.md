# SymbioGen ArangoDB Implementation Patterns

Real-world patterns from SymbioGen's codebase showing how python-arango-async is used in production.

## Table of Contents

1. [Connection Patterns](#connection-patterns)
2. [Agent Database Services](#agent-database-services)
3. [LangChain Tool Integration](#langchain-tool-integration)
4. [Common Query Patterns](#common-query-patterns)
5. [Caching Strategies](#caching-strategies)

---

## Connection Patterns

### Connection Pool (ai_engine/db/connection_pool.py)

SymbioGen uses a lightweight connection pool to manage database connections efficiently.

**Pattern:**
```python
# Singleton pool instance
_pool: Optional[ArangoConnectionPool] = None

async def get_connection_pool() -> ArangoConnectionPool:
    global _pool
    if _pool is None:
        _pool = ArangoConnectionPool(
            host=os.getenv("ARANGO_HOST", "http://localhost:8529"),
            database=os.getenv("ARANGO_DATABASE", "symbiogen_db"),
            username=os.getenv("ARANGO_USERNAME", "root"),
            password=os.getenv("ARANGO_PASSWORD", "password")
        )
        await _pool.initialize()
    return _pool
```

### Async Wrapper (ai_engine/db/async_connection.py)

Provides backwards-compatible convenience methods while using pooled connections.

**Pattern:**
```python
class AsyncDatabaseWrapper:
    """Wrapper around pooled StandardDatabase instance."""

    def __init__(self, pool, db: StandardDatabase):
        self._pool = pool
        self._db = db
        self._closed = False

    async def execute_aql(
        self,
        query: str,
        bind_vars: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> List[Dict[str, Any]]:
        cursor = await self._db.aql.execute(query, bind_vars=bind_vars, **kwargs)
        if hasattr(cursor, "__aiter__"):
            return [doc async for doc in cursor]
        return list(cursor or [])

    async def collection_insert(
        self, collection_name: str, document: Dict[str, Any], **kwargs
    ) -> Any:
        collection = self._db.collection(collection_name)
        return await collection.insert(document, **kwargs)

    async def collection_update(
        self, collection_name: str, document: Dict[str, Any], **kwargs
    ) -> Any:
        collection = self._db.collection(collection_name)
        kwargs.setdefault("merge", True)
        kwargs.setdefault("keep_none", False)
        return await collection.update(document, **kwargs)
```

**Usage:**
```python
from ai_engine.db.async_connection import get_async_connection

async def my_operation():
    db = await get_async_connection()
    results = await db.execute_aql(
        "FOR doc IN collection RETURN doc",
        bind_vars={}
    )
    return results
```

---

## Agent Database Services

### Base Pattern (ai_engine/db/database_service.py)

Unified database service with caching integration.

**Pattern:**
```python
class DatabaseService:
    """Unified database service for all AI Engine operations."""

    def __init__(self):
        self._db = None
        self._cache = None
        self._initialized = False
        self._stats = {
            "queries_executed": 0,
            "cache_hits": 0,
            "cache_misses": 0,
            "errors": 0,
            "total_query_time": 0.0
        }

    async def initialize(self):
        if self._initialized:
            return

        self._db = await get_async_connection()
        self._cache = await get_cache_service()
        self._initialized = True

    async def execute_aql(
        self,
        query: str,
        bind_vars: Optional[Dict[str, Any]] = None,
        use_cache: bool = True,
        cache_ttl: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        if not self._initialized:
            await self.initialize()

        # Check cache
        if use_cache and self._cache:
            cached = await self._cache.get_cached_query_result(query, bind_vars)
            if cached is not None:
                self._stats["cache_hits"] += 1
                return cached

        # Execute query
        results = await self._db.execute_aql(query, bind_vars)

        # Cache result
        if use_cache and self._cache:
            await self._cache.cache_query_result(query, bind_vars, results, cache_ttl)

        self._stats["queries_executed"] += 1
        return results
```

### Agent Extension Pattern (ai_engine/db/agents/chronicler_db.py)

Agent-specific database services extend the base service.

**Pattern:**
```python
from ai_engine.db.database_service import DatabaseService
from typing import Dict, List, Any, Optional
from datetime import datetime, timezone

class ChroniclerDatabaseService(DatabaseService):
    """Extended database service for Chronicler Agent operations."""

    def __init__(self):
        super().__init__()
        self.collections = {
            'executions': 'agent_executions',
            'conversations': 'conversations',
            'entities': 'extracted_entities',
            'intelligence_events': 'intelligence_events'
        }

    async def save_conversation_record(
        self,
        conversation: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Agent-specific method for conversation storage."""
        conversation['created_at'] = datetime.now(timezone.utc).isoformat()
        conversation['indexed_at'] = datetime.now(timezone.utc).isoformat()

        return await self.insert_document(
            self.collections['conversations'],
            conversation
        )

    async def get_conversations_by_timeframe(
        self,
        start_time: str,
        end_time: str,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Retrieve conversations within timeframe."""
        query = f"""
        FOR conv IN {self.collections['conversations']}
        FILTER conv.created_at >= @start_time
        FILTER conv.created_at <= @end_time
        SORT conv.created_at DESC
        LIMIT @limit
        RETURN conv
        """

        return await self.execute_aql(query, {
            'start_time': start_time,
            'end_time': end_time,
            'limit': limit
        })

# Singleton pattern
_chronicler_db_instance: Optional[ChroniclerDatabaseService] = None

async def get_chronicler_db() -> ChroniclerDatabaseService:
    global _chronicler_db_instance
    if _chronicler_db_instance is None:
        _chronicler_db_instance = ChroniclerDatabaseService()
        await _chronicler_db_instance.initialize()
    return _chronicler_db_instance
```

**Usage in Agent:**
```python
from ai_engine.db.agents.chronicler_db import get_chronicler_db

async def chronicler_node(state: State):
    db = await get_chronicler_db()

    # Use agent-specific methods
    conversations = await db.get_conversations_by_timeframe(
        start_time="2025-01-01T00:00:00Z",
        end_time="2025-12-31T23:59:59Z",
        limit=100
    )

    await db.save_conversation_record({
        "title": "Q4 Planning Meeting",
        "participants": ["john", "jane"],
        "summary": "Discussed 2025 goals"
    })

    return state
```

---

## LangChain Tool Integration

### ArangoDB Tools Pattern (ai_engine/db/arangodb/tools/)

LangChain tools for ArangoDB graph operations.

**Edge Upsert Tool:**
```python
from langchain_core.tools import ToolException
from ai_engine.db.arangodb.toolkit import BaseArangoGraphTool
from ai_engine.db.arangodb.edges import ArangoEdgeManager, EdgePayload

class ArangoEdgeUpsertTool(BaseArangoGraphTool):
    """Create or update edges within an ArangoDB graph."""

    name: str = "arangodb_edge_upsert"
    description: str = (
        "Insert or update an edge inside ArangoDB. "
        "Requires a collection name plus _from/_to handles."
    )

    def __init__(self, config, factory=None, **kwargs):
        super().__init__(config=config, factory=factory, **kwargs)
        self._manager = ArangoEdgeManager(self.factory)

    def _run(self, *args, **kwargs) -> Dict[str, Any]:
        params = self._parse_params(args, kwargs)
        payload = EdgePayload(
            collection=params.collection,
            from_id=params.from_id,
            to_id=params.to_id,
            key=params.key,
            attributes=params.attributes,
            graph_name=params.graph_name
        )
        try:
            return self._manager.upsert_edge(
                payload=payload,
                overwrite_mode=params.overwrite_mode
            )
        except Exception as exc:
            raise ToolException(f"Arango edge upsert failed: {exc}") from exc
```

**AQL Query Tool:**
```python
class ArangoAQLQueryTool(BaseArangoGraphTool):
    """Execute AQL queries using LangChain ArangoGraph semantics."""

    name: str = "arangodb_aql_query"
    description: str = "Run parameterised AQL queries and return JSON documents."

    def __init__(self, config, factory=None, **kwargs):
        super().__init__(config=config, factory=factory, **kwargs)
        self._executor = ArangoQueryExecutor(self.factory)

    def _run(self, *args, **kwargs) -> List[Dict[str, Any]]:
        params = self._parse_params(args, kwargs)
        try:
            return self._executor.run(
                query=params.query,
                bind_vars=params.bind_vars,
                limit=params.limit
            )
        except Exception as exc:
            raise ToolException(f"Arango query failed: {exc}") from exc
```

---

## Common Query Patterns

### Temporal Queries

**Get Current Valid State:**
```python
async def get_current_contacts():
    db = await get_async_connection()

    query = """
    FOR doc IN contacts
    FILTER doc.valid_from <= DATE_NOW()
    FILTER doc.valid_to == null OR doc.valid_to > DATE_NOW()
    RETURN doc
    """

    return await db.execute_aql(query)
```

**Historical As-Of Query:**
```python
async def get_contacts_as_of(date: str):
    db = await get_async_connection()

    query = """
    FOR doc IN contacts
    FILTER doc.valid_from <= @query_date
    FILTER doc.valid_to == null OR doc.valid_to > @query_date
    FILTER doc.transaction_time <= @query_date
    RETURN doc
    """

    return await db.execute_aql(query, {"query_date": date})
```

### Graph Traversals

**Find Connection Paths:**
```python
async def find_introduction_path(from_contact: str, to_contact: str):
    db = await get_async_connection()

    query = """
    FOR path IN OUTBOUND SHORTEST_PATH
    @start_vertex TO @end_vertex
    GRAPH @graph_name
    RETURN {
        vertices: path.vertices,
        edges: path.edges,
        path_length: LENGTH(path.edges)
    }
    """

    results = await db.execute_aql(query, {
        "start_vertex": from_contact,
        "end_vertex": to_contact,
        "graph_name": "business_network"
    })

    return results[0] if results else None
```

**Find Related Organizations:**
```python
async def get_related_organizations(contact_id: str):
    db = await get_async_connection()

    query = """
    FOR vertex, edge IN 1..2 OUTBOUND @contact
    GRAPH @graph_name
    FILTER vertex._id LIKE 'organizations/%'
    RETURN DISTINCT {
        organization: vertex,
        relationship_type: edge.type,
        connection_strength: edge.influence_level
    }
    """

    return await db.execute_aql(query, {
        "contact": contact_id,
        "graph_name": "business_network"
    })
```

### Aggregation Queries

**Agent Status Dashboard:**
```python
async def get_chronicler_status():
    db = await get_async_connection()

    query = """
    LET total_executions = LENGTH(
        FOR exec IN agent_executions
        FILTER exec.agent_name == 'chronicler'
        RETURN 1
    )
    LET successful = LENGTH(
        FOR exec IN agent_executions
        FILTER exec.agent_name == 'chronicler'
        FILTER exec.success == true
        RETURN 1
    )
    LET conversations_today = LENGTH(
        FOR conv IN conversations
        FILTER DATE_TIMESTAMP(conv.created_at) >=
               DATE_TIMESTAMP(DATE_NOW()) - 86400000
        RETURN 1
    )

    RETURN {
        total_executions: total_executions,
        successful_executions: successful,
        success_rate: successful / total_executions,
        conversations_processed_today: conversations_today
    }
    """

    result = await db.execute_aql(query)
    return result[0] if result else {}
```

---

## Caching Strategies

### Query Result Caching

```python
# In DatabaseService
async def execute_aql(
    self,
    query: str,
    bind_vars: Optional[Dict[str, Any]] = None,
    use_cache: bool = True,
    cache_ttl: Optional[int] = None
) -> List[Dict[str, Any]]:
    # Check cache first
    if use_cache and self._cache:
        cached_result = await self._cache.get_cached_query_result(
            query, bind_vars
        )
        if cached_result is not None:
            self._stats["cache_hits"] += 1
            return cached_result

    # Execute query
    results = await self._db.execute_aql(query, bind_vars)

    # Cache result
    if use_cache and self._cache:
        await self._cache.cache_query_result(
            query, bind_vars, results, cache_ttl
        )

    return results
```

**Usage:**
```python
# Cached query (default TTL)
results = await db.execute_aql(
    query,
    bind_vars,
    use_cache=True
)

# Cached with custom TTL (5 minutes)
results = await db.execute_aql(
    query,
    bind_vars,
    use_cache=True,
    cache_ttl=300
)

# Bypass cache for real-time data
results = await db.execute_aql(
    query,
    bind_vars,
    use_cache=False
)
```

---

## Best Practices from SymbioGen

1. **Always use connection pool**: Don't create new clients for each operation
2. **Extend DatabaseService**: Agent-specific services inherit base functionality
3. **Singleton pattern**: One database service instance per agent type
4. **Caching by default**: Use cache for read-heavy operations
5. **Bitemporal tracking**: Include temporal fields in all entities
6. **Bind variables**: Always use bind_vars for queries
7. **Error handling**: Log errors with context for debugging
8. **Statistics tracking**: Monitor cache hits, query counts, execution times
9. **Graph-first design**: Model relationships as edges, not foreign keys
10. **Collection naming**: Use plural, lowercase, underscored names

---

See also:
- [API Patterns](./api_patterns.md) for python-arango-async API reference
- [AQL Reference](./aql_reference.md) for query syntax
- [Schema Design](./schema_design.md) for architectural patterns
