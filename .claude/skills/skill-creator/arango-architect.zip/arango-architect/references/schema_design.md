# ArangoDB Schema Design Philosophy

Schema design patterns and decision frameworks for SymbioGen's graph-first architecture.

## Table of Contents

1. [Core Design Principles](#core-design-principles)
2. [Collection Design Decision Tree](#collection-design-decision-tree)
3. [Vertex vs Edge Design](#vertex-vs-edge-design)
4. [Bitemporal Schema Patterns](#bitemporal-schema-patterns)
5. [Index Strategy](#index-strategy)
6. [Schema Examples](#schema-examples)

---

## Core Design Principles

### 1. Graph-First Thinking

**Always think: Nodes and Edges, not Tables and Columns**

- **Entities = Vertices** (document collections)
- **Relationships = Edges** (edge collections)
- **Metadata = Document attributes**
- **Context = Edge attributes**

**Anti-Pattern (SQL Thinking):**
```python
# DON'T DO THIS
contact = {
    "_id": "contacts/john",
    "organization_id": "org_123",  # Foreign key - BAD
    "manager_id": "contact_456"    # Foreign key - BAD
}
```

**Correct Pattern (Graph Thinking):**
```python
# Vertex: Contact
contact = {
    "_id": "contacts/john",
    "name": "John Doe",
    "title": "Engineer"
    # No foreign keys!
}

# Edge: Works at organization
works_at = {
    "_from": "contacts/john",
    "_to": "organizations/org_123",
    "role": "Senior Engineer",
    "start_date": "2020-01-01"
}

# Edge: Reports to manager
reports_to = {
    "_from": "contacts/john",
    "_to": "contacts/manager",
    "relationship_type": "direct_report"
}
```

### 2. Bitemporal Truth

**Track two time dimensions for every entity:**

```python
entity = {
    # Entity data
    "name": "John Doe",
    "company": "Acme Corp",

    # Bitemporal tracking
    "valid_from": "2025-03-01T00:00:00Z",      # When true in reality
    "valid_to": None,                           # Still valid
    "transaction_time": "2025-03-15T10:30:00Z", # When we learned it

    # Metadata
    "confidence_score": 0.95,
    "source": "email_ingestion"
}
```

### 3. Multi-Model Integration

Use the right model for each aspect:

- **Documents**: Rich, unstructured business context
- **Graphs**: Relationship networks and traversals
- **Key-Value**: High-speed lookups and caching

### 4. Universal Vectorization

Every entity should support multi-dimensional analysis:

```python
contact = {
    "_key": "john_doe",
    "name": "John Doe",

    # Influence vectors (5 dimensions)
    "spec_driving_power": 0.8,
    "purchasing_power": 0.3,
    "strategic_power": 0.7,
    "networking_power": 0.9,
    "champion_power": 0.6,

    # Vector embedding for semantic search
    "embedding_vector": [0.12, -0.34, 0.56, ...]  # 768-dim vector
}
```

### 5. Semantic Preservation

Meaning must survive transformations:

```python
# GOOD - Preserved semantics
conversation = {
    "title": "Q1 Planning Discussion",
    "participants": ["john_doe", "jane_smith"],
    "key_topics": ["budget", "hiring", "roadmap"],
    "sentiment": "optimistic",
    "action_items_count": 5
}

# BAD - Lost semantics
conversation_flat = {
    "data": "Q1 Planning Discussion john_doe jane_smith budget hiring roadmap optimistic 5"
}
```

---

## Collection Design Decision Tree

### When to Create a New Collection

**Create a new collection when:**

1. **Distinct Domain Concept**
   - Represents a core business entity (Contact, Organization, Opportunity)
   - Has independent existence and lifecycle
   - Would be named as a "thing" in business discussions

2. **Independent Lifecycle**
   - Created, updated, deleted independently
   - Has own audit trail requirements
   - Needs separate access control

3. **Frequent Standalone Queries**
   - Often queried without parent entity
   - Has its own search/filter requirements
   - Benefits from dedicated indexes

4. **Graph Participation**
   - Acts as vertex in relationship graph
   - Acts as edge connecting other entities
   - Part of traversal queries

5. **Distinct Access Patterns**
   - Different read/write frequency than parent
   - Different caching requirements
   - Different security policies

### When to Enhance Existing Schema

**Add metadata fields when:**

1. **Purely Descriptive**
   - Describes existing entity
   - No independent meaning
   - Always accessed with parent entity

2. **Rarely Queried Independently**
   - Almost never filtered/searched alone
   - Not used in JOIN-like operations
   - No dedicated index needed

3. **Computed/Derived Values**
   - Calculated from other fields
   - Cached for performance
   - Can be regenerated if lost

4. **Temporal Snapshots**
   - Represents state at point in time
   - Part of bitemporal tracking
   - Versioned with parent entity

5. **Doesn't Change Entity Identity**
   - Adding field doesn't make it a different "thing"
   - Still the same conceptual entity
   - No new relationships created

### Decision Examples

**Example 1: Contact's Influence Score**
```
Question: Should influence scores be a separate collection?

Analysis:
- Distinct domain concept? NO (just a score)
- Independent lifecycle? NO (tied to contact)
- Frequently queried alone? NO
- Graph participation? NO
- Distinct access patterns? NO

Decision: Add as metadata fields to Contact
```

```python
contact = {
    "_key": "john_doe",
    "name": "John Doe",

    # Add influence scores as metadata
    "influence": {
        "spec_driving": 0.8,
        "purchasing": 0.3,
        "strategic": 0.7,
        "networking": 0.9,
        "champion": 0.6,
        "calculated_at": "2025-10-30T00:00:00Z"
    }
}
```

**Example 2: Meeting Transcripts**
```
Question: Should meeting transcripts be separate collection?

Analysis:
- Distinct domain concept? YES (meeting is a thing)
- Independent lifecycle? YES (created/deleted independently)
- Frequently queried alone? YES (search all meetings)
- Graph participation? YES (connects multiple contacts)
- Distinct access patterns? YES (different security)

Decision: Create new collection + edges
```

```python
# New collection: meetings
meeting = {
    "_key": "meeting_2025_10_30",
    "title": "Q1 Planning",
    "date": "2025-10-30T10:00:00Z",
    "transcript": "...",
    "duration_minutes": 60
}

# Edges: participated_in
edge1 = {
    "_from": "contacts/john_doe",
    "_to": "meetings/meeting_2025_10_30",
    "role": "organizer"
}

edge2 = {
    "_from": "contacts/jane_smith",
    "_to": "meetings/meeting_2025_10_30",
    "role": "participant"
}
```

---

## Vertex vs Edge Design

### Vertex (Document Collection) Pattern

**Use for entities that:**
- Represent distinct "things" in domain
- Have rich attributes
- Can exist independently
- Are starting/ending points for relationships

**Example Vertex Schema:**
```python
# Collection: contacts (vertex)
contact = {
    "_key": "john_doe",
    "_id": "contacts/john_doe",

    # Core attributes
    "name": "John Doe",
    "email": "john@example.com",
    "title": "Senior Engineer",

    # Bitemporal tracking
    "valid_from": "2020-01-01T00:00:00Z",
    "valid_to": None,
    "transaction_time": "2025-01-15T00:00:00Z",

    # Vectorization
    "influence_scores": {...},
    "embedding": [...],

    # Metadata
    "source": "email_ingestion",
    "confidence": 0.95
}
```

### Edge (Edge Collection) Pattern

**Use for relationships that:**
- Connect two entities
- Have directionality
- Carry contextual information about relationship
- Enable graph traversals

**Example Edge Schema:**
```python
# Collection: works_with (edge)
relationship = {
    "_key": "rel_123",
    "_id": "works_with/rel_123",

    # Required edge fields
    "_from": "contacts/john_doe",
    "_to": "organizations/acme_corp",

    # Relationship context
    "role": "Senior Engineer",
    "department": "Engineering",
    "start_date": "2020-01-01",
    "end_date": None,  # Current

    # Bitemporal tracking
    "valid_from": "2020-01-01T00:00:00Z",
    "valid_to": None,
    "transaction_time": "2025-01-15T00:00:00Z",

    # Relationship strength
    "interaction_frequency": "daily",
    "influence_level": 0.7
}
```

### Hybrid: Rich Edge Pattern

Some edges carry substantial context:

```python
# Complex edge: introduced
introduction = {
    "_from": "contacts/introducer",
    "_to": "contacts/introducee",

    # Introduction context
    "introduced_at": "2025-10-15T14:30:00Z",
    "context": "Q4 partnership discussion",
    "outcome": "successful",

    # Value tracking
    "resulting_deal_value": 250000,
    "relationship_strength_before": 0.0,
    "relationship_strength_after": 0.7,

    # Audit
    "introduced_by_agent": "ambassador",
    "confidence_score": 0.92
}
```

---

## Bitemporal Schema Patterns

### Standard Bitemporal Fields

Every entity should include:

```python
entity = {
    # ... entity-specific fields ...

    # Bitemporal tracking (MANDATORY)
    "valid_from": "ISO8601 timestamp",  # When entity state became valid
    "valid_to": "ISO8601 timestamp or null",  # When entity state ended (null = current)
    "transaction_time": "ISO8601 timestamp",  # When we recorded this state

    # Audit metadata (RECOMMENDED)
    "created_by": "system|user_id|agent_name",
    "source": "email_ingestion|user_input|api_import",
    "confidence_score": 0.0-1.0
}
```

### Versioning Pattern

Multiple versions of same entity:

```python
# Version 1 (historical)
contact_v1 = {
    "_key": "john_doe_v1",
    "entity_key": "john_doe",  # Links all versions
    "version": 1,
    "name": "John Doe",
    "company": "Old Corp",
    "valid_from": "2020-01-01T00:00:00Z",
    "valid_to": "2023-06-30T23:59:59Z",
    "transaction_time": "2020-01-15T00:00:00Z"
}

# Version 2 (current)
contact_v2 = {
    "_key": "john_doe_v2",
    "entity_key": "john_doe",  # Same entity, different version
    "version": 2,
    "name": "John Doe",
    "company": "New Corp",
    "valid_from": "2023-07-01T00:00:00Z",
    "valid_to": None,  # Current version
    "transaction_time": "2023-07-15T00:00:00Z"
}
```

### Query Current State

```aql
// Get current valid state
FOR doc IN contacts
FILTER doc.valid_from <= DATE_NOW()
FILTER doc.valid_to == null OR doc.valid_to > DATE_NOW()
RETURN doc
```

### Query Historical State

```aql
// What did we know on specific date?
LET query_date = DATE_TIMESTAMP(@as_of_date)

FOR doc IN contacts
FILTER doc.valid_from <= query_date
FILTER doc.valid_to == null OR doc.valid_to > query_date
FILTER doc.transaction_time <= query_date
RETURN doc
```

---

## Index Strategy

### Index Types

1. **Persistent Index (B-tree)** - Most common
2. **Hash Index** - Fast equality lookups
3. **Fulltext Index** - Text search
4. **Geo Index** - Geospatial queries
5. **TTL Index** - Auto-delete old documents

### When to Add Indexes

**Always index:**
- Fields used in FILTER clauses frequently
- Fields used in SORT operations
- Fields used in JOIN-like operations
- Email addresses (for uniqueness and lookups)
- Timestamps (for temporal queries)

**Consider indexing:**
- Graph edge `_from` and `_to` (automatic for edge collections)
- Multi-field combinations for common queries
- Sparse indexes for optional fields

**Avoid indexing:**
- Fields rarely filtered
- High-cardinality fields with even distribution
- Fields that change frequently
- Large text fields (use fulltext instead)

### Index Examples

```python
# Email uniqueness index
await collection.add_index({
    "type": "persistent",
    "fields": ["email"],
    "unique": True,
    "sparse": False
})

# Temporal query index
await collection.add_index({
    "type": "persistent",
    "fields": ["valid_from", "valid_to", "transaction_time"],
    "unique": False
})

# Compound index for common query
await collection.add_index({
    "type": "persistent",
    "fields": ["organization_id", "created_at"],
    "unique": False
})

# Full-text search
await collection.add_index({
    "type": "fulltext",
    "fields": ["description"],
    "minLength": 3
})

# TTL index (auto-delete after 30 days)
await collection.add_index({
    "type": "ttl",
    "fields": ["created_at"],
    "expireAfter": 2592000  # 30 days in seconds
})
```

---

## Schema Examples

### Contact Schema (Vertex)

```python
contact = {
    "_key": "john_doe",
    "_id": "contacts/john_doe",

    # Core identity
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+1-555-0100",
    "title": "Senior Software Engineer",

    # Influence vectors (SymbioGen specific)
    "influence": {
        "spec_driving_power": 0.75,
        "purchasing_power": 0.30,
        "strategic_power": 0.60,
        "networking_power": 0.85,
        "champion_power": 0.50
    },

    # Embedding for semantic search
    "embedding_vector": [...],  # 768-dim

    # Bitemporal tracking
    "valid_from": "2020-01-01T00:00:00Z",
    "valid_to": None,
    "transaction_time": "2025-01-15T10:30:00Z",

    # Metadata
    "source": "email_ingestion",
    "confidence_score": 0.92,
    "created_by": "chronicler_agent",
    "last_updated": "2025-10-30T00:00:00Z"
}
```

### Organization Schema (Vertex)

```python
organization = {
    "_key": "acme_corp",
    "_id": "organizations/acme_corp",

    # Core identity
    "name": "Acme Corporation",
    "domain": "acme.com",
    "industry": "Software",
    "size": "501-1000",

    # Organizational vectors
    "profile": {
        "risk_tolerance": 0.6,
        "innovation_appetite": 0.8,
        "decision_speed": 0.4,
        "budget_flexibility": 0.7
    },

    # Bitemporal
    "valid_from": "2015-01-01T00:00:00Z",
    "valid_to": None,
    "transaction_time": "2025-01-15T00:00:00Z",

    # Metadata
    "source": "crm_import",
    "confidence_score": 0.98
}
```

### Relationship Schema (Edge)

```python
works_at = {
    "_key": "rel_john_acme",
    "_id": "works_at/rel_john_acme",

    # Required edge fields
    "_from": "contacts/john_doe",
    "_to": "organizations/acme_corp",

    # Relationship details
    "role": "Senior Software Engineer",
    "department": "Engineering",
    "start_date": "2020-01-01",
    "end_date": None,

    # Interaction context
    "interaction_frequency": "daily",
    "influence_on_decisions": 0.65,

    # Bitemporal
    "valid_from": "2020-01-01T00:00:00Z",
    "valid_to": None,
    "transaction_time": "2025-01-15T00:00:00Z"
}
```

---

See also:
- [API Patterns](./api_patterns.md) for implementation details
- [AQL Reference](./aql_reference.md) for query patterns
- [SymbioGen Patterns](./symbiogen_patterns.md) for real-world examples
