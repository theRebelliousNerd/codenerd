---
name: arango-architect
description: Expert guidance for python-arango-async usage in SymbioGen including AQL syntax, schema design, async patterns, graph traversals, and architectural decisions on collection design vs metadata enhancement. Use when working with ArangoDB, writing AQL queries, designing graph schemas, or making database architecture decisions.
---

# ArangoDB Architect Skill

## Overview

Provide expert guidance for working with ArangoDB using python-arango-async in the SymbioGen backend. Cover connection management, async patterns, AQL query construction, graph traversal design, schema architecture decisions, and bitemporal data modeling aligned with SymbioGen's graph-first philosophy.

## When to Use This Skill

Invoke this skill when working with:
- AQL query writing, optimization, or debugging
- ArangoDB schema design (collections, graphs, edges, indexes)
- Async database patterns using python-arango-async
- Graph traversal queries and path finding
- Collection vs metadata enhancement decisions
- Bitemporal truth implementation
- Database service architecture in ai_engine/db/
- Agent-specific database extensions
- Performance optimization for queries
- Migration from synchronous to async patterns

## SymbioGen's Graph-First Philosophy

CRITICAL: Always think in graphs, not tables.

**Core Principles:**
1. **Nodes and Edges Before Metadata**: Model relationships as first-class graph edges, not foreign keys
2. **Bitemporal Truth**: Track both valid_time (when it happened) and transaction_time (when we learned about it)
3. **Multi-Model Integration**: Use documents for rich context, graphs for relationships, key-value for caching
4. **Universal Vectorization**: Every entity has multi-dimensional vector representations
5. **Graph-First Thinking**: If considering rows/columns, reconsider as vertices/edges

## Core Capabilities

### 1. Connection Management

SymbioGen uses a connection pool pattern for efficient async database access.

**Key Files:**
- `ai_engine/db/connection_pool.py` - Pooled connections
- `ai_engine/db/async_connection.py` - Async wrapper with convenience methods
- `ai_engine/db/database_service.py` - Unified service with caching

**Usage Pattern:**
```python
from ai_engine.db.async_connection import get_async_connection

# Get pooled connection (singleton pattern)
async def my_database_operation():
    db = await get_async_connection()
    results = await db.execute_aql(
        "FOR doc IN my_collection RETURN doc",
        bind_vars={}
    )
    return results
```

**Context Manager Pattern:**
```python
from ai_engine.db.async_connection import get_async_db

async def scoped_operation():
    async with get_async_db() as db:
        # Connection auto-released on exit
        return await db.execute_aql(query)
```

### 2. Query Execution Patterns

**Simple AQL Execution:**
```python
from ai_engine.db.database_service import DatabaseService

async def query_with_caching():
    db = DatabaseService()
    await db.initialize()

    # With automatic caching
    results = await db.execute_aql(
        """
        FOR doc IN students
        FILTER doc.age > @min_age
        SORT doc.name
        RETURN doc
        """,
        bind_vars={"min_age": 18},
        use_cache=True,
        cache_ttl=300  # 5 minutes
    )
    return results
```

**Direct python-arango-async Pattern:**
```python
async def direct_query():
    db = await get_async_connection()
    cursor = await db.aql.execute(
        "FOR doc IN collection RETURN doc",
        bind_vars={}
    )
    # AsyncDatabaseWrapper handles iteration automatically
    return [doc async for doc in cursor]
```

### 3. Collection Operations

**Document CRUD:**
```python
async def document_operations():
    db = await get_async_connection()

    # Insert single document
    await db.collection_insert("students", {
        "_key": "john",
        "name": "John Doe",
        "age": 22,
        "valid_from": "2025-01-01T00:00:00Z",
        "transaction_time": "2025-01-15T10:30:00Z"
    })

    # Bulk insert
    await db.bulk_insert("students", [
        {"_key": "jane", "name": "Jane Smith", "age": 21},
        {"_key": "bob", "name": "Bob Johnson", "age": 23}
    ])

    # Update (merge by default)
    await db.collection_update("students", {
        "_key": "john",
        "age": 23,
        "updated_at": "2025-10-30T00:00:00Z"
    })

    # Delete
    await db.collection_delete("students", "john")
```

### 4. Graph Traversal Patterns

**Creating Graph Structures:**
```python
async def setup_graph():
    db = await get_async_connection()

    # Create graph if not exists
    if not await db.has_graph("business_network"):
        graph = await db.create_graph("business_network")

        # Define edge definition
        await graph.create_edge_definition(
            edge_collection="works_with",
            from_vertex_collections=["contacts"],
            to_vertex_collections=["organizations"]
        )
```

**Traversal Queries:**
```python
async def find_connection_path():
    db = await get_async_connection()

    query = """
    FOR vertex, edge, path IN 1..3 OUTBOUND @start_vertex
    GRAPH @graph_name
    OPTIONS {
        bfs: true,
        uniqueVertices: 'global'
    }
    FILTER vertex.entity_type == @target_type
    RETURN {
        vertex: vertex,
        path_length: LENGTH(path.edges),
        edges: path.edges
    }
    """

    results = await db.execute_aql(query, {
        "start_vertex": "contacts/john_doe",
        "graph_name": "business_network",
        "target_type": "decision_maker"
    })
    return results
```

### 5. Schema Design Decision Framework

**When to Create a New Collection:**
- Entity represents a distinct domain concept (Contact, Organization, Opportunity)
- Entity needs independent lifecycle management
- Entity will be queried frequently as a standalone item
- Entity has distinct access patterns or security requirements
- Entity participates in graph relationships as vertex or edge

**When to Enhance Existing Schema with Metadata:**
- Data is purely descriptive of an existing entity
- Data is rarely queried independently
- Data represents computed/derived values
- Data is temporal snapshots of entity state
- Adding fields doesn't change entity's conceptual identity

**Example Decision Tree:**
```
New data: "Influence score for a contact"
├─ Is this a core entity attribute? YES
├─ Does it change over time? YES -> Use bitemporal metadata
├─ Is it frequently queried alone? NO
└─ DECISION: Add metadata field with temporal tracking

New data: "Meeting transcript"
├─ Is this a core entity? YES (distinct lifecycle)
├─ Does it relate to multiple entities? YES
├─ Will it be queried independently? YES
└─ DECISION: Create new collection + edge relationships
```

### 6. Bitemporal Truth Implementation

**Core Pattern:**
```python
async def insert_bitemporal_entity():
    db = await get_async_connection()

    # Every entity tracks dual time dimensions
    entity = {
        "_key": "contact_123",
        "name": "John Doe",
        "company": "Acme Corp",

        # Bitemporal tracking
        "valid_from": "2025-03-01T00:00:00Z",  # When it was true in reality
        "valid_to": None,  # Still valid
        "transaction_time": "2025-03-15T10:30:00Z",  # When we learned about it

        # Metadata
        "created_by": "system",
        "confidence_score": 0.95
    }

    await db.collection_insert("contacts", entity)
```

**Temporal Queries:**
```python
async def query_as_of_date():
    db = await get_async_connection()

    # "What did we know on 2025-03-10?"
    query = """
    FOR doc IN contacts
    FILTER doc.valid_from <= @query_date
    FILTER (doc.valid_to == null OR doc.valid_to > @query_date)
    FILTER doc.transaction_time <= @query_date
    RETURN doc
    """

    results = await db.execute_aql(query, {
        "query_date": "2025-03-10T00:00:00Z"
    })
    return results
```

### 7. Agent-Specific Database Services

**Pattern: Extend DatabaseService for Agent Needs**

Location: `ai_engine/db/agents/{agent_name}_db.py`

```python
from ai_engine.db.database_service import DatabaseService
from typing import Dict, List, Any, Optional

class ChroniclerDatabaseService(DatabaseService):
    """Extended database service for Chronicler Agent operations."""

    def __init__(self):
        super().__init__()
        self.collections = {
            'executions': 'agent_executions',
            'conversations': 'conversations',
            'entities': 'extracted_entities'
        }

    async def save_conversation_record(
        self,
        conversation: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Agent-specific method for conversation storage."""
        conversation['indexed_at'] = datetime.now(timezone.utc).isoformat()
        return await self.insert_document(
            self.collections['conversations'],
            conversation
        )

    async def get_conversations_by_timeframe(
        self,
        start_time: str,
        end_time: str,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Retrieve conversations within timeframe."""
        query = """
        FOR conv IN @@collection
        FILTER conv.created_at >= @start_time
        FILTER conv.created_at <= @end_time
        SORT conv.created_at DESC
        LIMIT @limit
        RETURN conv
        """

        return await self.execute_aql(query, {
            "@collection": self.collections['conversations'],
            "start_time": start_time,
            "end_time": end_time,
            "limit": limit
        })

# Singleton pattern
_instance: Optional[ChroniclerDatabaseService] = None

async def get_chronicler_db() -> ChroniclerDatabaseService:
    global _instance
    if _instance is None:
        _instance = ChroniclerDatabaseService()
        await _instance.initialize()
    return _instance
```

### 8. Index Strategy

**When to Add Indexes:**
- Fields used in FILTER clauses frequently
- Fields used in SORT operations
- Fields used in JOIN-like operations
- Graph edge _from/_to fields (automatic for edge collections)
- Geospatial queries on coordinates

**Index Types:**
```python
async def create_indexes():
    db = await get_async_connection()
    collection = db.collection("contacts")

    # Persistent index (B-tree)
    await collection.add_index({
        "type": "persistent",
        "fields": ["email"],
        "unique": True,
        "sparse": False
    })

    # Multi-field index for common queries
    await collection.add_index({
        "type": "persistent",
        "fields": ["organization_id", "created_at"],
        "unique": False
    })

    # Full-text search index
    await collection.add_index({
        "type": "fulltext",
        "fields": ["description"],
        "minLength": 3
    })
```

### 9. Performance Optimization

**Query Optimization Checklist:**
1. Use FILTER early in query (before expensive operations)
2. Use indexes on filtered fields
3. LIMIT results when appropriate
4. Use projection (RETURN specific fields, not full documents)
5. Avoid COLLECT on large datasets without filters
6. Use bind variables (prevents AQL injection, enables query caching)

**Example: Optimized vs Unoptimized**
```python
# UNOPTIMIZED
"""
FOR doc IN large_collection
LET related = (FOR r IN relations FILTER r.contact_id == doc._id RETURN r)
FILTER LENGTH(related) > 0
SORT doc.created_at DESC
RETURN doc
"""

# OPTIMIZED
"""
FOR doc IN large_collection
FILTER doc.has_relations == true  // Indexed field
SORT doc.created_at DESC
LIMIT @limit
RETURN {
    id: doc._id,
    name: doc.name,
    created_at: doc.created_at
}
"""
```

### 10. Error Handling and Telemetry

**Robust Error Handling:**
```python
async def safe_database_operation():
    db = DatabaseService()
    await db.initialize()

    try:
        results = await db.execute_aql(query, bind_vars)

        # Log successful execution
        logger.info(f"Query executed: {len(results)} results")

        return results

    except Exception as e:
        # Log error with context
        logger.error(
            f"Database operation failed: {e}",
            extra={
                "query": query,
                "bind_vars": bind_vars,
                "error_type": type(e).__name__
            }
        )
        # Re-raise or handle appropriately
        raise
```

## Quick Reference

**Common Files:**
- `ai_engine/db/database_service.py` - Main database service with caching
- `ai_engine/db/async_connection.py` - Async connection wrapper
- `ai_engine/db/connection_pool.py` - Connection pooling
- `ai_engine/db/agents/{agent}_db.py` - Agent-specific extensions
- `ai_engine/db/arangodb/tools/` - LangChain tools for ArangoDB

**Detailed References:**
- [API Patterns](./references/api_patterns.md) - python-arango-async API guide
- [AQL Reference](./references/aql_reference.md) - Comprehensive AQL syntax guide
- [Schema Design](./references/schema_design.md) - Design philosophy and patterns
- [SymbioGen Patterns](./references/symbiogen_patterns.md) - Existing implementation patterns

**Query Templates:**
- `assets/query_templates/basic_crud.aql` - Insert, update, delete patterns
- `assets/query_templates/graph_traversal.aql` - Common traversal patterns
- `assets/query_templates/bitemporal_query.aql` - Temporal query examples
- `assets/query_templates/aggregation.aql` - GROUP BY, COLLECT patterns
- `assets/query_templates/optimization.aql` - Performance-optimized examples

## Workflow Decision Tree

```
Task: Work with ArangoDB in SymbioGen
|
├─ Need to execute a query?
│  ├─ Simple query -> Use DatabaseService.execute_aql()
│  ├─ Complex traversal -> See graph_traversal.aql template
│  └─ Optimization needed -> See optimization.aql template
|
├─ Need to design schema?
│  ├─ New entity -> Check decision framework (Section 5)
│  ├─ Enhance existing -> Add bitemporal metadata fields
│  └─ Graph relationships -> Create edge collections
|
├─ Building agent database service?
│  ├─ Extend DatabaseService class
│  ├─ Add agent-specific methods
│  ├─ Implement singleton pattern
│  └─ Place in ai_engine/db/agents/{agent}_db.py
|
├─ Performance issue?
│  ├─ Review query optimization checklist (Section 9)
│  ├─ Add indexes if needed (Section 8)
│  └─ Enable query caching in DatabaseService
|
└─ Migration or refactoring?
   ├─ Review existing patterns in symbiogen_patterns.md
   ├─ Follow async connection patterns
   └─ Maintain bitemporal tracking
```

## Resources

### references/
Comprehensive documentation on python-arango-async patterns, AQL syntax, schema design philosophy, and SymbioGen's existing implementation patterns.

### assets/query_templates/
Reusable AQL query templates for common operations, optimized for SymbioGen's use cases with bitemporal tracking and graph traversals.

### scripts/
Helper utilities for database operations (if needed for migrations or batch operations).

---

**Remember:** SymbioGen thinks in graphs. Every architectural decision should answer: "How does this support discovering the perfect person/product for this specific context at this exact moment?"
